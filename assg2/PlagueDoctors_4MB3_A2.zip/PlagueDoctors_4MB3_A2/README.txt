To compile the final PDF:

1.
Make sure knitr and deSolve packages are downloaded in Studio and that knitr is your default program to weave Rnw files 
2. 
Open PlagueDoctors_4MB3_A2.Rnw in RStudio
3. 
Either press the button “compile PDF” or run the commands:
	library(knitr)
	knit(“PlagueDoctors_4MB3_A2.Rnw”)
4. 
If you pressed the button, the PDF should be open in your default viewer. If you ran the commands, open the resulting .tex file with your preferred LaTeX program and compile the PDF.


